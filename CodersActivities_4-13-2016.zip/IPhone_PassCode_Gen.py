# IPhone Passcode Generator
passgen = []
for a in range(0, 10):
    for b in range(0, 10):
        for c in range(0, 10):
            for d in range(0, 10):
                passgen.append(str(a)+str(b)+str(c)+str(d))
print(passgen)
