import math

inum = int(input("Enter Integer: "))
number = inum
result = 0

while number > 0:
    num = number%10
    number = math.floor(number/10)
    result += num**3
    
print(str(inum)+" is an armstrong number." if result==inum else str(inum)+" is not an armstrong number.")
