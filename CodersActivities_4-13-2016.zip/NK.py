# N! / ( K! ( N - K )! )
try:
    n = int(input("Enter N: "))
    k = int(input("Enter K: "))
except:
    print("Error!")
    
def factorial(num):
    ans = num
    for n in range(num, 1, -1):
        ans *= n-1
    return ans
    

print(factorial(n) / ( factorial(k) * factorial(n-k)))
