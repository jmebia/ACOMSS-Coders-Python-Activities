questions = ("Who are you?","How old are you?","What is your favorite food?")
responses = ("Greetings, ", " years old, you are.", ", too! I like.")

chat_file = open("YodaChatBot.txt","w")

print("Greetings Padawan! Master Yoda, I am.\n")
chat_file.write("Greetings Padawan! Yoda Chat-Bot, I am. \n")

for num in range(3):
    answer = input(questions[num]+"\n"+"Answer: ")
    print(responses[num]+answer+"\n" if(num<1) else answer+responses[num]+"\n")
    chat_file.write("\n"+questions[num])
    chat_file.write("\n"+answer+"\n")
    chat_file.write(responses[num]+answer+"\n" if(num<1) else answer+responses[num]+"\n")
    
chat_file.flush()
chat_file.close()    
