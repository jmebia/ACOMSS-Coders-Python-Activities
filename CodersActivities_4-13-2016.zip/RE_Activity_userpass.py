import re

def login():
    username = input("Username: ")
    password = input("Password: ")
    if re.fullmatch(username,'myusername') and re.fullmatch(password,'mypassword'):
        print('Info Unlocked...')
        print('Penguins are sea-birds in the family Spheniscidae.')
    else:
        print('Incorrect Username and/or Password!')
    
