# Anagram
import re

def anagram():
    input_ = input("Enter a word: ")
    anag = input("Enter an anagram of {}: ".format(input_))
    isAnagram = False

    for w in input_:
        for anagw in anag:
            if w == anagw:
                isAnagram = True; anag.replace(anagw,"")
                break
            else:
                isAnagram = False

    print(anag+" is an anagram of "+input_ if(isAnagram) else anag+" is not an anagram of "+input_ )

