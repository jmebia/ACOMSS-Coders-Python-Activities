# Randomizer
from random import randint

for n in range(30):
    sn = str(randint(2014,2015))
    sn += str(randint(1,2))
    for number in range(5):
        sn += str(randint(0,9))
    print(sn)      
