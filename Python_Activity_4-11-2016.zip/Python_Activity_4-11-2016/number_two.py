a = []
while True:
    i = input("Enter String: ")
    if i is not "": a.append(i)
    else : break

print(a)
