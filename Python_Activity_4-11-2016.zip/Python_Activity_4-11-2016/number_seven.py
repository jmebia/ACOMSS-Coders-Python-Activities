for i in range(1,6):
    text=""
    for n in range(i):
        text += str(n+1)
    print(text)
