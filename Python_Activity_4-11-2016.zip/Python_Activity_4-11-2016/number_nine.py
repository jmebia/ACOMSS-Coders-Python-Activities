s = input("Enter String: ")
text = ""
for i in s:
    text = i + text
print(text)
