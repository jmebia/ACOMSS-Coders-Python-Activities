while True:
    if int(input("Enter an integer: ")) != 0:continue
    else: break
