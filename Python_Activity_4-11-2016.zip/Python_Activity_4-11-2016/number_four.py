for i in range(1,31):
    if i % 3 == 0 and i % 5 == 0:print(i, ": BingBong")
    elif i % 5 == 0 : print(i, ": Bong")
    elif i % 3 == 0 : print(i , ": Bing")
    else : print(i, ": None")
