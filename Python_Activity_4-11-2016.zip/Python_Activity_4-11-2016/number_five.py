array = [3,5,-4,3,4,3]
text="There is no negative number in the list"
for i in array:
     if i < 0 :
         text = "There is a negative number in the list"
         break
print(text)
     
