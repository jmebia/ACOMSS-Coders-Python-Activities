array = ["foo","boo","bool"]
text = "There is a 'b' in "
for i in array :
    if "b" in i :
        text += i
        text += " "
print(text)
