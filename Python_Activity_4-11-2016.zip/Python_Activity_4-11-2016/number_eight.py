s = input("Enter a string: ")
text=""
for i in s:
    if "a" in i : i = "*"
    elif "e" in i : i = "3"
    elif "i" in i : i = "9"
    text += i
print(text)
